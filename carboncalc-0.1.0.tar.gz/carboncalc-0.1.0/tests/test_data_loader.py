# test_data_loader.py
import sys
import os

# Ajouter le répertoire parent au sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from carboncalc.data_loader import load_emission_factors

def test_load_emission_factors(tmp_path):
    """
    Teste le chargement des facteurs d'émission.
    """
    # Création de fichiers CSV temporaires
    aliments_csv = tmp_path / "aliments.csv"
    aliments_csv.write_text("main_type,CO2\nCéréales,2.5\nViandes,3.0")
    
    energie_csv = tmp_path / "energie.csv"
    energie_csv.write_text("french_name,CO2\nElectricité,0.2\nGaz,0.5")
    
    equipements_csv = tmp_path / "equipements.csv"
    equipements_csv.write_text("french_name,CO2\nFrigo,1.5\nFour,1.0")

    factors = load_emission_factors(aliments_csv, energie_csv, equipements_csv)
    assert "aliments" in factors
    assert factors["aliments"]["Céréales"] == 2.5
