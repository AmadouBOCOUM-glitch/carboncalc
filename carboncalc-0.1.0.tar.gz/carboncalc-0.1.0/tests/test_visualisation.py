# test_visualisation.py
import sys
import os

# Ajouter le répertoire parent au sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import pytest
from carboncalc.visualisation import plot_emissions

def test_plot_emissions():
    """
    Teste la fonction `plot_emissions` (non bloquant).
    """
    emissions = {"aliments": 10, "energie": 5, "equipements": 3}
    try:
        plot_emissions(emissions)
    except Exception as e:
        pytest.fail(f"Erreur lors de la visualisation : {e}")


