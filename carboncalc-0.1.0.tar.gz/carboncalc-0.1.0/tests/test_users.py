# test_users.py
import sys
import os

# Ajouter le répertoire parent au sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from carboncalc.users import ask_user

def test_ask_user(monkeypatch):
    """
    Teste la fonction `ask_user` avec des entrées simulées.
    """
    inputs = iter(["mensuelle", "1", "5.0", "0", "1", "10.0", "0", "1", "1", "2.0", "0"])
    monkeypatch.setattr('builtins.input', lambda _: next(inputs))
    user_data = ask_user()
    assert user_data["periode"] == "mensuelle"
    assert "aliments" in user_data
    assert "energie" in user_data
    assert "equipements" in user_data
