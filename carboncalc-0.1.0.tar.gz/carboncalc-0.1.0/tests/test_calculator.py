# test_calculator.py
import sys
import os

# Ajouter le répertoire parent au sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from carboncalc.calculator import calculate_emissions

def test_calculate_emissions():
    """
    Teste le calcul des émissions.
    """
    user_data = {
        "periode": "hebdomadaire",
        "aliments": {"Céréales": 2, "Viandes": 1},
        "energie": {"type": "Electricité", "qty": 10},
        "equipements": {"Frigo": {"quantite": 1, "duree_utilisation": 24}},
    }
    emission_factors = {
        "aliments": {"Céréales": 2.5, "Viandes": 3.0},
        "energie": {"Electricité": 0.2},
        "equipements": {"Frigo": 1.5},
    }
    emissions = calculate_emissions(user_data, emission_factors)
    assert emissions["total"] > 0
