from setuptools import setup, find_packages
from pathlib import Path

# Lire le fichier README.md pour la description longue du projet
long_description = Path('README.md').read_text()

setup(
    name='carboncalc',  # Nom du projet
    version='0.1.0',    # Version du projet
    author='Amadou Bocoum',
    author_email='amadouboc22@gmail.com',
    description='Un package Python pour calculer les émissions de CO₂.',
    long_description=long_description,  # Lire le contenu de README.md
    long_description_content_type='text/markdown',  # Le format du README
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    packages=find_packages(),  # Trouver automatiquement tous les packages
    python_requires='>=3.7',  # La version minimum de Python requise
    install_requires=[
        'pandas',     # Dépendance pour le calcul des données
        'matplotlib', # Dépendance pour la visualisation
        'seaborn',    # Dépendance pour les visualisations avancées
    ],
)
