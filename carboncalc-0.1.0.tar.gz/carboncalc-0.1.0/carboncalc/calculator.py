# --------------------------------------------------------------
# Fonction 3 : Calculer les émissions
# --------------------------------------------------------------

def calculate_emissions(user_data, emission_factors):
    """
    Calcule les émissions de carbone en utilisant les données utilisateur
    et les facteurs d'émission chargés.
    """
    emissions = {"total": 0}

    # Catégorie Alimentation
    for aliment, qty in user_data["aliments"].items():
        # Récupérer la moyenne des émissions pour l'aliment
        average_cod = emission_factors["aliments"].get(aliment, 0)
        emissions["aliments"] = emissions.get("aliments", 0) + qty * average_cod
    
    # Catégorie Énergie
    energie_type = user_data["energie"]["type"]
    energie_qty = user_data["energie"]["qty"]
    emissions["energie"] = energie_qty * emission_factors["energie"].get(energie_type, 0)

    # Catégorie Équipements
    for equipement, data in user_data["equipements"].items():
        quantite = data["quantite"]
        duree = data["duree_utilisation"]
        
        # Récupérer la moyenne des émissions pour l'équipement
        average_cod = emission_factors["equipements"].get(equipement, 0)
        
        emissions["equipements"] = emissions.get("equipements", 0) + quantite * duree * average_cod

    # Ajustement selon la période
    period_factors = {"hebdomadaire": 1, "mensuelle": 4, "annuelle": 52}
    emissions["total"] = sum(emissions.values()) * period_factors.get(user_data["periode"], 0)
    return emissions
