# --------------------------------------------------------------
# Fonction 1 : Collecter les réponses utilisateur
# --------------------------------------------------------------
def ask_user():
    """
    Pose des questions à l'utilisateur pour collecter ses habitudes de consommation.
    Retourne un dictionnaire contenant les réponses pour chaque catégorie :
    - Période d'évaluation (hebdomadaire, mensuelle, annuelle)
    - Alimentation : Quantités consommées pour divers types d'aliments
    - Énergie : Type d'énergie utilisé et quantité consommée
    - Équipements : Équipements utilisés, quantités et durées d'utilisation
    """
    print("Veuillez répondre aux questions ci-dessous pour calculer votre empreinte carbone.\n")

    # 1. Choix de la période d'évaluation
    while True:
        choice = input("Quel type d'évaluation souhaitez-vous faire ? (hebdomadaire, mensuelle ou annuelle) : ").lower()
        if choice in ["hebdomadaire", "mensuelle", "annuelle"]:
            break
        print("Veuillez choisir parmi les options : hebdomadaire, mensuelle ou annuelle.")
    
    # Initialisation du dictionnaire des réponses
    responses = {"periode": choice}

    # 2. Collecte des réponses pour la catégorie Alimentation
    def saisir_aliments():
        """
        Permet à l'utilisateur de saisir ses habitudes alimentaires.
        Retourne un dictionnaire contenant les quantités pour chaque type d'aliment.
        """
        print("\nCatégorie : Alimentation")
        questions_aliments = [
            "Produits céréaliers",
            "Boissons",
            "Fruits, légumes, légumineuses et oléagineux",
            "Entrées et plats composés",
            "Lait et produits laitiers",
            "Viandes, oeufs, poissons",
            "Aides culinaires et ingrédients divers",
            "Produits sucrés",
            "Glaces et sorbets",
            "Matières grasses",
            "Aliments infantiles"
        ]

        aliment_quantities = {}
        
        # Affichage des options pour l'utilisateur
        for i, aliment in enumerate(questions_aliments, start=1):
            print(f"{i}. {aliment}")
        
        while True:
            try:
                choix = int(input("\nEntrez le numéro de l'aliment (ou 0 pour terminer) : "))
                if choix == 0:
                    break
                if 1 <= choix <= len(questions_aliments):
                    aliment = questions_aliments[choix - 1]
                    quantity = float(input(f"Combien de kg/litres de {aliment} consommez-vous chaque semaine ? "))
                    aliment_quantities[aliment] = quantity
                else:
                    print("Numéro invalide. Veuillez réessayer.")
            except ValueError:
                print("Veuillez entrer un nombre valide.")
        
        return aliment_quantities

    responses["aliments"] = saisir_aliments()

    # 3. Collecte des réponses pour la catégorie Énergie
    def saisir_energie():
        """
        Permet à l'utilisateur de saisir sa consommation énergétique.
        Retourne un dictionnaire contenant le type d'énergie et la quantité consommée.
        """
        print("\nCatégorie : Énergie")
        energy_types = [
            "Electricité",
            "Fioul domestique",
            "Gaz naturel - 2022",
            "Granulés"
        ]
        
        while True:
            print("Types d'énergie disponibles :")
            for i, energy_type in enumerate(energy_types, start=1):
                print(f"{i}. {energy_type}")
            
            try:
                choice = int(input("\nChoisissez un type d'énergie (ou 0 pour terminer) : "))
                if choice == 0:
                    break
                if 1 <= choice <= len(energy_types):
                    energy_type = energy_types[choice - 1]
                    quantity = float(input(f"Quelle est votre consommation hebdomadaire pour {energy_type} (kWh pour électricité, litre pour fioul, m3 pour gaz, kg pour granulés)? "))
                    return {"type": energy_type, "qty": quantity}
                else:
                    print("Numéro invalide. Veuillez réessayer.")
            except ValueError:
                print("Veuillez entrer un nombre valide.")

    responses["energie"] = saisir_energie()

    # 4. Collecte des réponses pour la catégorie Équipements
    def saisir_equipements():
        """
        Permet à l'utilisateur de saisir les informations sur les équipements utilisés.
        Retourne un dictionnaire contenant les équipements, leurs quantités et durées d'utilisation.
        """
        print("\nCatégorie : Équipements")
        equipements_disponibles = [
            "Appareil à raclettes 6-8p",
            "Aspirateur ménager",
            "Aspirateur professionnel",
            "Ballon électrique chauffe-eau 200L",
            "Bouilloire",
            "Climatiseur mobile",
            "Congélateur",
            "Four",
            "Gazinière",
            "Hotte décorative",
            "Hotte visière",
            "Lave-linge",
            "Lave-vaisselle",
            "Machine à café",
            "Machine à pain",
            "Micro-ondes",
            "Mini-four",
            "Plaques de cuisson",
            "Radiateur électrique",
            "Réfrigérateur"
        ]

        print("Liste des équipements disponibles :")
        for i, equipement in enumerate(equipements_disponibles, start=1):
            print(f"{i}. {equipement}")
        
        equipements_utilises = {}
        
        while True:
            try:
                choix = int(input("\nEntrez le numéro de l'équipement utilisé (ou 0 pour arrêter) : "))
                if choix == 0:
                    break
                if 1 <= choix <= len(equipements_disponibles):
                    equipement = equipements_disponibles[choix - 1]
                    quantite = int(input("Quantité utilisée : "))
                    duree_utilisation = float(input("Durée d'utilisation en heures par jour : "))
                    equipements_utilises[equipement] = {"quantite": quantite, "duree_utilisation": duree_utilisation}
                else:
                    print("Numéro invalide. Veuillez réessayer.")
            except ValueError:
                print("Veuillez entrer des valeurs numériques valides.")
        
        return equipements_utilises

    responses["equipements"] = saisir_equipements()

    return responses

