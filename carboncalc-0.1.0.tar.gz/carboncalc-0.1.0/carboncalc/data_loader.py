import pandas as pd

# --------------------------------------------------------------
# Fonction 2 : Charger les facteurs d'émission
# --------------------------------------------------------------

def load_emission_factors(aliments_path, energie_path, equipements_path):
    """
    Charge les facteurs d'émission depuis des fichiers CSV et calcule les moyennes des émissions pour les aliments et les équipements.
    """
    try:
        # Charger les données depuis les CSV
        aliments_df = pd.read_csv(aliments_path)
        energie_df = pd.read_csv(energie_path)
        equipements_df = pd.read_csv(equipements_path)

        # Calculer la moyenne des CO2 pour chaque aliment
        aliments_avg = aliments_df.groupby("main_type")["CO2"].mean().to_dict()

        # Calculer la moyenne des CO2 pour chaque équipement
        equipements_avg = equipements_df.groupby("french_name")["CO2"].mean().to_dict()

        return {
            "aliments": aliments_avg,  # Moyenne des émissions pour chaque aliment
            "energie": dict(zip(energie_df["french_name"], energie_df["CO2"])),
            "equipements": equipements_avg,  # Moyenne des émissions pour chaque équipement
        }
    except Exception as e:
        raise RuntimeError(f"Erreur lors du chargement des fichiers CSV : {e}")
