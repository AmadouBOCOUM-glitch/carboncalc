import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

# -----------------------------------------------------
# Fonction 4 : Visualiser les résultats
# --------------------------------------------------------------
def plot_emissions(emissions):
    """
    Visualisation des émissions carbone par poste avec Seaborn, inspirée des rapports comme ceux de Carbone43.
    """
    # Préparer les données
    categories = ["aliments", "energie", "equipements"]
    values = [emissions.get(cat, 0) for cat in categories]

    # Créer un DataFrame pour Seaborn
    data = pd.DataFrame({
        "Poste": categories,
        "Émissions (Tonnes)": values
    })

    # Configurer le style Seaborn
    sns.set_theme(style="whitegrid")
    plt.figure(figsize=(10, 6))

    # Ajouter une colonne pour hue (utilisation des couleurs en fonction des catégories)
    data["Couleur"] = data["Poste"]

    # Barplot avec Seaborn, en liant 'Poste' à 'hue'
    sns.barplot(data=data, x="Poste", y="Émissions (Tonnes)", hue="Couleur", palette="coolwarm")

    # Ajouter des annotations au-dessus des barres
    for index, value in enumerate(values):
        plt.text(index, value + 0.2, f"{value:.2f}", ha='center', fontsize=12, color="black")

    # Ajouter des détails de présentation
    plt.title("Émissions Carbone par Poste (en Tonnes)", fontsize=18, fontweight="bold")
    plt.ylabel("Tonnes de CO2", fontsize=14)
    plt.xlabel("Postes", fontsize=14)
    plt.grid(axis='y', linestyle='--', alpha=0.7)

    plt.show()

    # Ajouter une visualisation supplémentaire (Diagramme circulaire)
    plt.figure(figsize=(8, 8))
    plt.pie(
        values, 
        labels=categories, 
        autopct='%1.1f%%', 
        startangle=90, 
        colors=sns.color_palette("coolwarm", len(categories)), 
        explode=[0.1 if v == max(values) else 0 for v in values]  # Mettre en évidence le poste dominant
    )
    plt.title("Répartition des Émissions Carbone par Poste", fontsize=16, fontweight="bold")
    plt.show()
     
