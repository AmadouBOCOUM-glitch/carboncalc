# carboncalc - Calculateur d'Émissions de CO₂

**carboncalc** est un package Python conçu pour aider les restaurants à évaluer leurs émissions de CO₂.  
Il prend en compte des facteurs tels que :
- L'utilisation des équipements électriques.
- La consommation énergétique.
- Les types et quantités d'aliments utilisés.

Ce projet vise à promouvoir une gestion durable et à réduire l'empreinte carbone dans le secteur de la restauration.

---

## Installation

### Prérequis

- **Python 3.7 ou plus récent** doit être installé sur votre machine.  
  Vous pouvez vérifier votre version de Python avec la commande suivante :
  ```bash
  python --version
  ```

- **pip**, le gestionnaire de packages Python, est également nécessaire.  
  Vérifiez qu'il est installé avec :
  ```bash
  pip --version
  ```

### Étapes d'installation

Clonez le dépôt sur votre machine locale :

```bash
git clone <URL-DU-REPO>
cd carboncalc
```

Installez le package en mode local avec la commande suivante :

```bash
pip install .
```

---


## Structure des données

Les fichiers CSV nécessaires au fonctionnement du programme se trouvent déjà dans le dossier suivant :

```plaintext
data/
/---Base_Carbone_V23.4.csv
├── aliments.csv
├── equipements.csv
└── energie.csv
```

Assurez-vous que ces fichiers contiennent les bonnes données avant d'exécuter le programme. Si besoin, vous pouvez les modifier directement dans ce dossier.

---


## Utilisation

### Scripts principaux

Les scripts se trouvent dans le répertoire `carboncalc/`.  
Pour utiliser le calculateur d'émissions, exécutez le fichier principal avec Python :

```bash
python main.py
```

### Instructions détaillées

Lorsque vous exécutez le script, vous serez invité à fournir des informations spécifiques sur :
- L'énergie consommée (kWh pour électricité, litre pour fioul, m³ pour gaz, kg pour granulés).
- Les types d'équipements utilisés.
- La quantité d'aliments produits.

Le programme calculera les émissions totales de CO₂ et fournira un résumé clair des résultats.

---

## Contribuer

Nous accueillons toutes les contributions pour améliorer ce projet ! Voici comment vous pouvez contribuer :

1. **Fork** ce dépôt.
2. Créez une branche pour vos modifications :
   ```bash
   git checkout -b feature/nom-de-la-branche
   ```
3. Soumettez vos modifications avec un **Pull Request**.

---

## Avenir du projet

Nous prévoyons d'ajouter :
- Une interface utilisateur graphique (GUI) pour une utilisation plus intuitive.
- Une intégration avec des API pour des bases de données sur les émissions de CO₂ des produits.
- Des visualisations interactives des résultats.

---

## Aide et support

Si vous rencontrez des problèmes ou si vous avez des questions, n'hésitez pas à ouvrir une **Issue** dans ce dépôt ou à me contacter à l'adresse suivante :  
**amadouboc22@gmail.com**

---

## Licence

Ce projet est sous licence MIT. Consultez le fichier [LICENSE](./LICENSE) pour plus de détails.

---

## Exemple de sortie

Lors de l'exécution du script principal, voici un exemple de résultat :  

```plaintext
Calculateur d'Émissions de CO₂
-------------------------------
Énergie consommée : 150 kWh
Équipement utilisé : four industriel
Aliments : 50 kg de viande, 20 kg de légumes

Émissions totales : 234.5 kg CO₂
```
